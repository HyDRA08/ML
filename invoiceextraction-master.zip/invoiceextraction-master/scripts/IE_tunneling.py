import nest_asyncio
from pyngrok import ngrok
import uvicorn
def api_tunneling(port):
	ngrok_tunnel = ngrok.connect(port)
	print('Public URL:', ngrok_tunnel.public_url)
	return {'public_url':'ngrok_tunnel.public_url)
