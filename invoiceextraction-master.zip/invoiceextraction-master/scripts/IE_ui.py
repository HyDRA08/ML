import gradio as gr
from pathlib import Path
import datetime
import shutil
import requests
from wand.image import Image as WImage
import cv2
list_not_display = []

# function which will accept input file and password.
def invoiceExtractorUI(input_text, invoice_file):
    pdf_path=None
    time_stamp = datetime.datetime.utcnow()
    print((invoice_file.name))
    #output_path = f"/home/qburst/anaconda3/envs/spaceApp/lib/python3.8/site-packages/gradio/static/img/{time_stamp.date()}"
    # creating a folder with date as name to save uploaded files in each day
    output_path = f"/home/athul/DataExtraction/scripts/output/static/img/{time_stamp.date()}"

    Path(output_path).mkdir(parents=True, exist_ok=True)
    #copying uploaded files to a permanaent location
    if Path(invoice_file.name).suffix == ".pdf":
        shutil.move(invoice_file.name, f'{output_path}/{time_stamp.time()}_{(Path(invoice_file.name)).stem}.pdf')
        pdf_path = f'{output_path}/{time_stamp.time()}_{(Path(invoice_file.name)).stem}.pdf'
        img_path = f'{output_path}/{time_stamp.time()}_{(Path(invoice_file.name)).stem}.jpg'
        # relative path  used to display image  in html script
        img_path_relative=f'/static/img/{time_stamp.date()}/{time_stamp.time()}_{(Path(invoice_file.name)).stem}.jpg'
        # for pdf file we will create an image to display in ui
        try:
            img = WImage(filename=pdf_path)
            img.save(filename=img_path)
        except Exception as e:
            print(e)
            list_not_display.append(pdf_path)

    else:
        shutil.move(invoice_file.name, f'{output_path}/{time_stamp.time()}_{(Path(invoice_file.name)).stem}.jpg')
        img_path = f'{output_path}/{time_stamp.time()}_{(Path(invoice_file.name)).stem}.jpg'
        img = cv2.imread(img_path)
        img = cv2.resize(img, None, fx=1.2, fy=1.2, interpolation=cv2.INTER_CUBIC)
        cv2.imwrite(img_path, img)
        img_path_relative=f'/static/img/{time_stamp.date()}/{time_stamp.time()}_{(Path(invoice_file.name)).stem}.jpg'

    html = """<!DOCTYPE html>
<html>
<head>
<style>
    
div.ex3 {
  background-color: lightblue;
  width: 450px;
  height: 350px;
  overflow: auto;
}


</style>
</head>
<body>




<div class="ex3">><img src=""" + img_path_relative + """> </div>


</body>
</html>"""

    if pdf_path:
        data = {"data": {
            "list_filepaths": [pdf_path],"password":input_text
        }}
    else:
        data = {"data": {
            "list_filepaths": [img_path],'access_token':'1234567asdfgh',"ui":1
        }}

    url="http://0.0.0.0:5051/invoiceExtraction"

    header={'access_token': '1234567asdfgh'}
    res = requests.post(url, json=data["data"],headers=header)

    return html, res.json()[0]


iface = gr.Interface(fn=invoiceExtractorUI,
                     inputs=[gr.inputs.Textbox(label="Please enter password for protected pdf's."),
                             gr.inputs.File(label="invoice file")],
                     outputs=[gr.outputs.HTML(label="Preview"), gr.outputs.JSON(label="Detected Values")],
                     flagging_options=["Correct", "Wrong"],
                     title="Invoice Extraction",
                     description="An application to automatically detect Invoice Number,Invoice Amount and"
                                 " Invoice Date.Dont forget to  flag the result appropriately by selecting the value from drop down list.",
                     layout="unaligned")
# login credentials
iface.launch(auth=("spaceApp_user","spaceApp_pwd"),debug=True,share=True)
#iface.launch(auth=("spaceApp_user","spaceApp_pwd"),debug=True)
