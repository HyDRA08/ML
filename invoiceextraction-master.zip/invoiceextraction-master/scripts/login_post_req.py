import requests
import json
from pathlib import Path
from requests.auth import HTTPBasicAuth
url = 'http://0.0.0.0:5051/login'
headers = {'content-type': 'application/json'}
auth = HTTPBasicAuth('spaceApp_user', 'spaceApp_pwd')
print(auth)
print(f"start")
r = requests.post(url, headers=headers,auth=auth)
#r_get =requests.get(url='http://0.0.0.0:5051/login',auth=auth)

print(r.text)
#print(r_get.text)
#print(f'end')
'''
url='http://0.0.0.0:5051/uploadfile'
headers = {'content-type': 'multipart/form-data'}


input_file='/home/qburst/Downloads/test_files1/20200528-204626_BSNL.pdf'
file_name = Path(input_file).name
files={'file': (file_name, open(input_file, 'rb'))}
r = requests.post(url=url,auth=auth, files=files)
print(f"upload file {r.text}")'''
'''curl -X 'POST' \
  'http://0.0.0.0:5052/uploadfile/' \
  -H 'accept: application/json' \
  -H 'Content-Type: multipart/form-data' \
  -F 'file=@20200528-204617_Airtel_Apr_2020.jpg;type=image/jpeg'''
