from IE_ocr import det_file_type_ocr
from IE_information_extraction import information_extraction
import datetime
import time
import os
import aiofiles
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from fastapi import Security, Depends, FastAPI, HTTPException
from fastapi.security.api_key import APIKeyQuery, APIKeyCookie, APIKeyHeader
from fastapi.openapi.docs import get_swagger_ui_html
from starlette.status import HTTP_403_FORBIDDEN
from pydantic import BaseModel
import secrets
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi import FastAPI, File, UploadFile
tags_metadata = [
   
    {
        "name": "invoiceExtraction",
        "description": "Function to automatically extract fields like _Invoice Number,Invoice Amount,and Invoice Date_ from uploaded invoices",
        "externalDocs": {
            "url": " http://0.0.0.1:5051/",
        },
    },
]
# access_token  for calling restapi
API_KEY = "1234567asdfgh"
API_KEY_NAME = "access_token"
COOKIE_DOMAIN = "0.0.0.0"
api_key_query = APIKeyQuery(name=API_KEY_NAME, auto_error=False)
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)
api_key_cookie = APIKeyCookie(name=API_KEY_NAME, auto_error=False)
app = FastAPI(title="InvoiceExtraction",
              description="This is a project to automatically extract fields like _Invoice Number,Invoice Amount,and Invoice Date_ from uploaded invoices",
              version="2.5.0", openapi_tags=tags_metadata)
origins = ["http://localhost.tiangolo.com", "https://localhost.tiangolo.com", "http://0.0.0.0",
           "http://localhost:8080", ]
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"],
                   allow_headers=["*"], )

security = HTTPBasic()

class login_cred(BaseModel):
  user_name: str
  password: str
class invoiceExtraction(BaseModel):
    list_filepaths: list
    password: Optional[str] = None
    ui: Optional[int] = 0

class invoiceExtractionRes(BaseModel):
    content_string: str
# Function to validate credentials    
def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    correct_username = secrets.compare_digest(credentials.username, "spaceApp_user")
    correct_password = secrets.compare_digest(credentials.password, "spaceApp_pwd")
    print(f"spaceApp_user {credentials.username} spaceApp_pwd {credentials.password}")
    if not (correct_username and correct_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
           headers={"WWW-Authenticate": "Basic"},
        )
    return API_KEY

async def get_api_key(
       
        api_key_header: str = Security(api_key_header),
       
):
    
    if api_key_header == API_KEY:
        return api_key_header
    
    else:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN, detail="Could not validate credentials"
        )
# Endpoint to get current username
@app.post("/login")
def post_current_user(username: str =Depends(get_current_username)):
    return {"api_key": username}
# Endpoint to upload file and extract required values from uploaded file
@app.post("/uploadFile")
async def create_upload_file(password=None,file: UploadFile = File(...),APIKey: str =Depends(get_api_key)):
    print(f"file upload {APIKey}")
    destination_folder="./upload_ui"
    out_file_path=os.path.join(destination_folder,f"{datetime.datetime.utcnow()}__{file.filename}")
    # ...
    async with aiofiles.open(out_file_path, 'wb') as out_file:
        while content := await file.read(1024):
            #content = await file.read()
            # async read chunk
            await out_file.write(content)  # async write chun
    list_filepaths = [out_file_path]
    password = password
    for doc_path in list_filepaths:
        try:
            print(f"doc_path {doc_path}")
            time_start = time.time()
            type_file, content_string, password = det_file_type_ocr(doc_path, password)

        except Exception as e:
            print(f'Error occur in det_file_type_ocr function {e}')
            list_files_not_processes.append(doc_path)
            return [{"invoice_number":"Not able to extract","invoice_amount":"Not able to extract","invoice_date":"Not able to extract","content_string":"Not able to perform OCR"}]
        try:
            print(f"type_file {type_file}")
            time_ocr = time.time() - time_start
            result = information_extraction(content_string, doc_path, type_file, time_ocr, password)
            print(f"result {result}")
            return result
        except Exception as e:
            print(f'Error occur in information_extraction function {e}')
            list_files_not_processes.append(doc_path)
        return {""}
    return {"filename": file.filename}



list_files_not_processes = []
#End point for batch processing
@app.post("/invoiceExtraction", tags=["invoiceExtraction"])
def invoiceExtraction(invoice_extraction: invoiceExtraction, APIKey=Depends(get_api_key)):
    list_filepaths = invoice_extraction.list_filepaths
    password = invoice_extraction.password
    for doc_path in list_filepaths:
        try:
            print(f"doc_path {doc_path}")
            time_start = time.time()
            type_file, content_string, password = det_file_type_ocr(doc_path, password)

        except Exception as e:
            print(f'Error occur in det_file_type_ocr function {e}')
            list_files_not_processes.append(doc_path)
            return {""}
        try:
            print(f"type_file {type_file}")
            time_ocr = time.time() - time_start
            result = information_extraction(content_string, doc_path, type_file, time_ocr, password)
            print(f"result {result}")
            return result
        except Exception as e:
            print(f'Error occur in information_extraction function {e}')
            list_files_not_processes.append(doc_path)
        return {""}


#if __name__ == "__main__":
#    uvicorn.run('IE_app:app', host='0.0.0.0', port=5051, debug=True, workers=3)
