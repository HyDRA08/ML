import numpy as np
from PIL import Image

img = Image.open('/home/athul/DataExtraction/input_files/Reimbursement_Images_3/20200528-200325_2.jpg')
lr_img = np.array(img)
from ISR.models import RDN

#rdn = RDN(weights='psnr-small')
rdn = RDN(weights='psnr-small')
sr_img = rdn.predict(lr_img)
Image.fromarray(sr_img)

sr_img = rdn.predict(lr_img, by_patch_of_size=50)
Image.fromarray(sr_img)