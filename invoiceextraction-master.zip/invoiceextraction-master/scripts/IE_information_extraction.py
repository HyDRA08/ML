from haystack.reader.transformers import TransformersReader
from IE_utils import file_info_detection, df_info_detection, df_filter, extract_amount,extract_invoice_number, extract_date
import os
import re
import datetime
from pathlib import Path
import pandas as pd
import numpy as np
import time
import gc
#import tensorflow as tf
list_not_processed = []
# enabling gpu
gpu = 0
# Loading pretrained transformer QA model for information extraction from ocr output
print(f"loading transformer models________________________________________________________________________________")
#for gpu_device in tf.config.experimental.list_physical_devices('GPU'):
#    tf.config.experimental.set_memory_growth(gpu_device, True)
reader_albert_xxlargev1_squad2_512 = TransformersReader(model_name_or_path="./transformer_models/albert_xxlargev1_sqd2_512/",use_gpu=gpu)
reader_deepset_roberta = TransformersReader(model_name_or_path="./transformer_models/roberta-base-squad2", use_gpu=gpu)
# function which take ocr output as input and give extracted fields  as output
def information_extraction(content_string, doc_path, type_file, time_ocr,password):
    print(f"inside extraction function")
    # Questions used to extract required fields
    questions_dict ={"questions_amount_pdf_mob": ["what is the invoice amount in words?", "what is the invoice amount in Rupees?"],
                     "questions_amount_pdf": ["what is the invoice amount?", "what is the sale in Rs.?", "what is the amount?"]}
    invoice_no_petrol = ["what is the invoice no?", "what is the bill no?"]
    date_petrol = ["what is the invoice date?", "what is the date?"]
    time_extraction = time.time()
    invoice_amount_words = False
    output_ans_list = []
    list_ans = []
    petrol_img = False
    # "invoice date" word is replaced by "D number" inside ocr function for easy and accurate extraction of invoice date .
    #For better extraction in petrol images we replace word "invoice number" with "icode number".
    # if file type is pdf_mob_file  first we will try to extract amount in words
    if type_file == "pdf_mob_file" or type_file=="img_mob":
        if content_string.lower().count("d number ")>0:
            date_petrol = ["what is the D number?"]
        else:
             date_petrol = ["what is the invoice date?"]
    if type_file == "pdf_mob_file":
        print(f"content_string inside extraction {content_string}")
        output_df = file_info_detection(questions_dict['questions_amount_pdf_mob'], doc_path, content_string,reader_deepset_roberta)
        output_df_double_filtered = df_info_detection(output_df, reader_deepset_roberta)
        output_df_double_filtered['detected_answer'] = output_df_double_filtered.apply(
            lambda x: extract_amount(x.answer, petrol_img, only_words=True), axis=1)
        if len(output_df_double_filtered) > 0:
            output_df_double_filtered = output_df_double_filtered[
                ~output_df_double_filtered.detected_answer.isin(["amount not able to detect"])]
            if len(output_df_double_filtered) > 0:
                df_amount_2_sort_words = df_filter(output_df_double_filtered, [0],questions_dict['questions_amount_pdf_mob'])
                sort_amount_words = df_amount_2_sort_words[ ~df_amount_2_sort_words.detected_answer.isin(["amount not able to detect"])]
                output_amount = sort_amount_words
                output_amount["Detected Field"] = ["Invoice Amount"]
                list_ans.append(sort_amount_words["answer"].to_list()[0])
                if len(list_ans) == 1:
                    invoice_amount_words = True
            else:
                output_amount = pd.DataFrame(
                    columns=["answer", "score", "probability", "context", "offset_start", "offset_end",
                             "document_id", "meta",
                             "query", "fileName", "detected_answer", "filter_value", "a_bsum", "Detected Field"])
                output_amount["Detected Field"] = ["Invoice Amount"]
        else:
            output_amount = pd.DataFrame(
                columns=["answer", "score", "probability", "context", "offset_start", "offset_end", "document_id",
                         "meta", "query", "fileName", "detected_answer", "filter_value", "a_bsum",
                         "Detected Field"])
            output_amount["Detected Field"] = ["Invoice Amount"]
    #Extracting amount in numerics
    if invoice_amount_words == False:
        bill_list = [".*bill|bill.*"]
        r_bill = re.compile(f"(?i)({bill_list[0]})")
        bill_list = list(filter(r_bill.match, content_string.split(" ")))
        if len(bill_list) < 1:
            invoice_no_petrol = ["what is the invoice no?"]
        else:
            invoice_no_petrol = ["what is the invoice no?", "what is the bill no?"]
        if type_file == "pdf_petrol_file" or type_file == "img_petrol":
            if content_string.count("icode number")>0:
                if content_string.count("invoice number: ")>0:
                    invoice_no_petrol = ["what is the icode number?","what is the invoice number:?" ]
                else:
                    invoice_no_petrol = ["what is the icode number?"]
            else:
                invoice_no_petrol = ["what is the invoice no:?", "what is the bill no:?" ]
        else:
            questions_dict["questions_amount_pdf"] = ["what is the invoice amount?", "what is the total  amount?", "what is the total charges?", "What is the total amount due?"]
        output_df_roberta = file_info_detection(questions_dict["questions_amount_pdf"], doc_path, content_string, reader_deepset_roberta)
        print(f"output_df_roberta {output_df_roberta}")
        output_df_roberta.to_csv("amount_roberta.csv")
        output_df_xlm = file_info_detection(questions_dict["questions_amount_pdf"], doc_path, content_string,reader_albert_xxlargev1_squad2_512, threshold=0.35)
        output_df_xlm.to_csv("amount_output_df_xlm.csv")
        petrol_img = False
        if output_df_roberta.empty and output_df_xlm.empty:
            list_ans.append("amount not able to detect")
        else:
            if type_file=='img_mob':
                #output_df=output_df_xlm
                output_df = pd.concat([output_df_roberta, output_df_xlm], axis=0)

            else:
                output_df = pd.concat([output_df_roberta, output_df_xlm], axis=0)
            output_df_double_filtered_xlm = df_info_detection(output_df, reader_albert_xxlargev1_squad2_512)
            output_df_double_filtered = pd.concat( [output_df_double_filtered_xlm])
            output_df_double_filtered['detected_answer'] = output_df_double_filtered.apply(lambda x: extract_amount(x.answer, petrol_img, only_words=False), axis=1)
            output_df_double_filtered = output_df_double_filtered[   ~output_df_double_filtered.detected_answer.isin(["amount not able to detect"])]
            if type_file  =="img_mobile":
                filter_list_amount_numerics = [ 0.5, 0.3, 0] 
            else:   
                filter_list_amount_numerics = [0.7, 0.6, 0.5, 0.3, 0]
            output_df_double_filtered.to_csv("amount1.csv", index=False)
            df_amount_2_sort_numerics = df_filter(output_df_double_filtered, filter_list_amount_numerics, questions_dict["questions_amount_pdf"])
            sort_amount_numerics = df_amount_2_sort_numerics[~df_amount_2_sort_numerics.detected_answer.isin(["amount not able to detect"])]
            sort_amount_numerics.to_csv("amount.csv", index=False)
            if sort_amount_numerics.empty:
                output_amount = pd.DataFrame(
                    columns=["answer", "score", "probability", "context", "offset_start", "offset_end",
                             "document_id", "meta", "query", "fileName", "detected_answer", "filter_value",
                             "a_bsum", "Detected Field"])
                output_amount["Detected Field"] = ["Invoice Amount"]
                list_ans.append("amount not able to detect")
            else:
                output_amount = sort_amount_numerics
                output_amount["Detected Field"] = ["Invoice Amount"]
                list_ans.append(sort_amount_numerics["answer"].to_list()[0])
    # Extracting invoice number for all type of files
    output_df = file_info_detection(invoice_no_petrol, doc_path, content_string, reader_albert_xxlargev1_squad2_512, threshold=0)
    if output_df.empty:
        output_invoice_number = pd.DataFrame(
            columns=["answer", "score", "probability", "context", "offset_start", "offset_end", "document_id",
                     "meta",
                     "query", "fileName", "detected_answer", "filter_value", "a_bsum", "Detected Field"])
        output_invoice_number["Detected Field"] = ["Invoice Number"]
        list_ans.append("invoice number not able to detect")
    else:
        output_df_double_filtered = df_info_detection(output_df, reader_albert_xxlargev1_squad2_512)
        output_df_double_filtered['detected_answer'] = output_df_double_filtered.apply(
            lambda x: extract_invoice_number(x.answer), axis=1)
        output_df_double_filtered = output_df_double_filtered[ ~output_df_double_filtered.detected_answer.isin(["invoice number not able to detect"])]
        output_df_double_filtered.to_csv("invoice_number.csv", index=False)
        if type_file =="pdf_mob_file" or type_file =="img_mobile":
            filter_list_invoice_number = [0.95,0.9, 0.6, 0.5, 0.3, 0]
        else:
            filter_list_invoice_number = [  0.5, 0.3, 0]
        df_invoice_number = df_filter(output_df_double_filtered, filter_list_invoice_number,invoice_no_petrol)
        output_invoice_number = df_invoice_number[ ~df_invoice_number.detected_answer.isin(["invoice number not able to detect"])]
        if output_invoice_number.empty:
            list_ans.append("invoice number not able to detect")
            output_invoice_number = pd.DataFrame(
                columns=["answer", "score", "probability", "context", "offset_start", "offset_end",
                         "document_id", "meta", "query", "fileName", "detected_answer", "filter_value",
                         "a_bsum", "Detected Field"])
        else:
            try:
                list_ans.append(output_invoice_number["answer"].to_list()[0].upper())
            except Exception as e:
                list_ans.append(output_invoice_number["answer"].to_list()[0])
        output_invoice_number["Detected Field"] = ["Invoice Number"]

    #Extracting invoice date from ocr output.
    output_df = file_info_detection(date_petrol, doc_path, content_string,reader_albert_xxlargev1_squad2_512, threshold=0)
    print(f"output_df {output_df}")
    if output_df.empty:
        output_invoice_date = pd.DataFrame(
            columns=["answer", "score", "probability", "context", "offset_start", "offset_end", "document_id",
                     "meta",
                     "query", "fileName", "detected_answer", "filter_value", "a_bsum", "Detected Field"])
        output_invoice_date["Detected Field"] = ["Invoice Date"]
        list_ans.append("date not able to detect")
    else:
        output_df_double_filtered = df_info_detection(output_df, reader_albert_xxlargev1_squad2_512)
        print(f"output_df_double_filtered {output_df_double_filtered}")
        output_df_double_filtered['detected_answer'] = output_df_double_filtered.apply(lambda x: extract_date(x.answer), axis=1)
        print(f"output_df_double_filtered {output_df_double_filtered['detected_answer']}")
        output_df_double_filtered = output_df_double_filtered[~output_df_double_filtered.detected_answer.isin(["date not able to detect"])]
        output_df_double_filtered.to_csv("date.csv", index=False)
        filter_list_invoice_date = [0.9, 0.8, 0.7, 0.6, 0.5, 0.3, 0]
        df_invoice_date = df_filter(output_df_double_filtered, filter_list_invoice_date, date_petrol)
        output_invoice_date = df_invoice_date[ ~df_invoice_date.detected_answer.isin(["date not able to detect"])]
        if output_invoice_date.empty:
            list_ans.append("date not able to detect")
            output_invoice_date = pd.DataFrame(
                columns=["answer", "score", "probability", "context", "offset_start", "offset_end",
                         "document_id", "meta",
                         "query", "fileName", "detected_answer", "filter_value", "a_bsum", "Detected Field"])
        else:
            list_ans.append(output_invoice_date["answer"].to_list()[0])
        output_invoice_date["Detected Field"] = ["Invoice Date"]

    output_answer_df = pd.concat([output_amount, output_invoice_number, output_invoice_date], axis=0)
    output_ans_list.append(output_answer_df)
    output_answer_df_full = pd.concat(output_ans_list, axis=0)
    output_answer_df_full = output_answer_df_full.replace(np.nan, '', regex=True)
    file_name = list(set(output_answer_df_full["fileName"].to_list()))
    file_name = [x for x in file_name if str(x) != '']
    output_answer_df_full_filtered = output_answer_df_full[output_answer_df_full["fileName"].isin([file_name])]
    output_answer_df_full_filtered["Invoice Number"] = [
        output_answer_df_full[output_answer_df_full["Detected Field"].isin(["Invoice Number"])][
            "detected_answer"].to_list()[0]]
    output_answer_df_full_filtered["Invoice Date"] = [
        output_answer_df_full[output_answer_df_full["Detected Field"].isin(["Invoice Date"])][
            "detected_answer"].to_list()[0]]
    output_answer_df_full_filtered["Invoice Amount"] = [
        output_answer_df_full[output_answer_df_full["Detected Field"].isin(["Invoice Amount"])][
            "detected_answer"].to_list()[0]]
    output_answer_df_full_filtered["File Name"] = file_name
    output_answer_df_full_filtered["Orginal answer"] = [str(list_ans)]
    result = output_answer_df_full_filtered[["File Name", "Invoice Number", "Invoice Date", "Invoice Amount", "Orginal answer"]]
    result["invoice_number"]=result["Invoice Number"]
    result["invoice_date"]=result["Invoice Date"]
    result["invoice_amount"]=result["Invoice Amount"]
    result["File Type"] = type_file
    result["OCR Output"] = content_string
    time_execution = time.time() - time_extraction + time_ocr
    result["TotalTime"] = time_execution
    result["OCRTime"] = time_ocr
    result["password"] =password
    #writing output to a csv file
    result.to_csv("./output/output3.csv",mode="a", header=False, index=False)
    result_dict = result.to_dict(orient="records")
    result_dict[0]["content_string"] = content_string

    return result_dict

