import textdistance
from pathlib import Path
import pandas as pd
from IE_utils import reader_pdf,sorted_text
import matplotlib
import matplotlib.pyplot as plt
plt.switch_backend('agg')
# configutring matplotlib parameters
plt.rcParams['figure.dpi'] = 100
plt.rcParams['figure.figsize']=[6.4, 4.8]
plt.rcParams['figure.edgecolor']='white'
plt.rcParams['figure.facecolor']='white'
plt.rcParams['figure.subplot.bottom']='0.11'
plt.rcParams['interactive']=False
print('matplotlib: {}'.format(matplotlib.__version__))
from pdf2image import convert_from_path
import sys
from paddleocr import PaddleOCR
from PIL import Image
from ISR.models import RDN
import ocrmypdf
import pdftotext
import cv2
import numpy as np
import re
import tempfile
from skimage.transform import  rotate
import os
#loading paddleocr version 2 models
print(f"loading ocr models_________________________________________________________")
ocr = PaddleOCR(use_angle_cls=True, lang='ch', det_model_dir="./ocr_models/ch_ppocr_server_v2.0_det_infer",
                rec_model_dir="./ocr_models/ch_ppocr_server_v2.0_rec_infer",
                cls_model_dir="./ocr_models/ch_ppocr_mobile_v2.0_cls_infer",
                use_space_char=True,cls=True,use_gpu=True)

#To replace words using textdistance package
dict_simillarity={}
dict_simillarity["invoice number: "]=["inv#","inv","sn","billsn","1nv","b117no","invno"]
dict_simillarity["invoice"]=["invoice","bill","b77","receipt","bi","bi11","recept","final"]
dict_simillarity["amount"]=["amount","mount"]
dict_simillarity["invoice amount"]=["total"]

#list of words to identify type of bill (petrol/mobile)
mobile_bill = [".*airtel.*", "vodafone.*", "bsnl.*", "roaming.*", "asianet.*", "internet.*","sanchar.*",
               "broadband.*", "ldea ","idea",".*vodafone","telecommunications.*","railtel.*","package.*","renewal.*","raiitel.*","!dea.*","fiber",'jio','network',"recharge"]
petrol_bill = ['petro.*', 'diese.*', 'preset.*', 'nozzle.*', 'volume.*', 'densit.*','card.*',"dealer.*","ehicl.*","fuel.*","etrol.*","please visit again.*"]

#creating regex patterns from above lists
combined_mobile = "(" + ")|(".join(mobile_bill) + ")"
combined_petrol_bill = "(" + ")|(".join(petrol_bill) + ")"

#calculating dpi value
fig = plt.gcf()
DPI = fig.get_dpi()
print(f"##############{DPI}")
print(plt.rcParams['figure.figsize'])

#function to remove shadows from image
def shadow_removal(img):
    rgb_planes = cv2.split(img)
    result_norm_planes = []
    for plane in rgb_planes:
        dilated_img = cv2.dilate(plane, np.ones((7,7), np.uint8))
        bg_img = cv2.medianBlur(dilated_img, 21)
        diff_img = 255 - cv2.absdiff(plane, bg_img)
        norm_img = cv2.normalize(diff_img,None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8UC1)
        result_norm_planes.append(norm_img)
    result_norm = cv2.merge(result_norm_planes)
    return result_norm

#function to calculate simillarity score
def simillarity_check(orginal_word):
    list_simillarity_score = []
    dict_word = {}
    orginal_word=re.sub('[^A-Za-z0-9]+', '', orginal_word)
    for key_word, list_word in dict_simillarity.items():
        for word in list_word:
            list_simillarity_score.append(textdistance.levenshtein.normalized_distance(orginal_word, word))
        list_simillarity_score = sorted(list_simillarity_score, reverse=False)
        dict_word[key_word] = list_simillarity_score[0]
    sort_word = sorted(dict_word.items(), key=lambda x: x[1], reverse=False)
    return sort_word[0][0], sort_word[0][1]

#function to replace words based on simillarity score
def replace_words(row):
    threshold = 0.4
    if row['target_word'] <= threshold:
        val = row['simillarity']
    else:
        val = row['ocr_words']
    return val

#function to resize image for better accuracy of paddleOCR
def resize_image_type0(im):
    """
    resize image to a size multiple of 32 which is required by the network
    args:
        img(array): array with shape [h, w, c]
    return(tuple):
        img, (ratio_h, ratio_w)
    """
   #max_side_len = max_side_len
    max_side_len = 1500
    h, w, _ = im.shape

    resize_w = w
    resize_h = h

    # limit the max side
    if max(resize_h, resize_w) > max_side_len:
        if resize_h > resize_w:
            ratio = float(max_side_len) / resize_h
        else:
            ratio = float(max_side_len) / resize_w
    else:
        ratio = 1.
    resize_h = int(resize_h * ratio)
    resize_w = int(resize_w * ratio)
    if resize_h % 32 == 0:
        resize_h = resize_h
    elif resize_h // 32 <= 1:
        resize_h = 32
    else:
        resize_h = (resize_h // 32 - 1) * 32
    if resize_w % 32 == 0:
        resize_w = resize_w
    elif resize_w // 32 <= 1:
        resize_w = 32
    else:
        resize_w = (resize_w // 32 - 1) * 32
    try:
        if int(resize_w) <= 0 or int(resize_h) <= 0:
            return None, (None, None)
        im = cv2.resize(im, (int(resize_w), int(resize_h)))
    except:
        print(im.shape, resize_w, resize_h)
        sys.exit(0)
    ratio_h = resize_h / float(h)
    ratio_w = resize_w / float(w)
    return im, (ratio_h, ratio_w)

#function to normalize input image  for better accuracy of paddleOCR
def normalize( im):
    img_mean = [0.485, 0.456, 0.406]
    img_std = [0.229, 0.224, 0.225]
    im = im.astype(np.float32, copy=False)
    im = im / 255
    im[:, :, 0] -= img_mean[0]
    im[:, :, 1] -= img_mean[1]
    im[:, :, 2] -= img_mean[2]
    im[:, :, 0] /= img_std[0]
    im[:, :, 1] /= img_std[1]
    im[:, :, 2] /= img_std[2]
    return im

#loading super resolution deep learning model using ISR package
rdn = RDN(arch_params={'C':3, 'D':20, 'G':64, 'G0':64, 'x':2},weights='psnr-small')
#rdn = RDN(weights='psnr-large')

#function to convert input image to pdf first.Then to text file using ocrmypdf package.
def img_pdf_text(input_img_path):
  img_file = tempfile.NamedTemporaryFile(suffix='.jpg')
  pdf_file=tempfile.NamedTemporaryFile(suffix='.pdf')
  lr_img = Image.open(input_img_path)
  file_size = os.path.getsize(input_img_path)
  file_size/=1024
  print(f"file_size {file_size}")
  #Removing alpha channel from input image
  if lr_img.mode == 'RGBA':
      lr_img = lr_img.convert('RGB')
  lr_img = np.array(lr_img)
  if file_size<900:
    sr_img = rdn.predict(lr_img,by_patch_of_size=50)
  else:
    sr_img=lr_img
  sr_img=Image.fromarray(sr_img)
  sr_img.convert("L").save(img_file.name,dpi=(3000,3000))
  ocrmypdf.ocr(img_file.name, pdf_file.name,image_dpi=600)
  with open(pdf_file.name, "rb") as f:
      pdf = pdftotext.PDF(f, )
      pdf0 = pdf[0]
      print("pdf0", pdf0)
  content ={}
  content['content_string']=pdf0
  img_file.close()
  pdf_file.close()
  return content

# function remove alphachannel from input
def fig2image(fig):
    """Convert a Matplotlib figure to a PIL Image and return it"""
    import io
    buf = io.BytesIO()
    fig.savefig(buf)
    buf.seek(0)
    img = Image.open(buf)
    print(f"img {img}")
    if img.mode == 'RGBA':
        img = img.convert('RGB')
    return img
# function to convert current figure to numpy array
def gcf_array(img,dpi_value=1500/DPI,cmap='bone'):
    plt.figure(figsize=(dpi_value,dpi_value))
    plt.axis("off")
    plt.imshow(img, cmap=cmap)
    fig_gcf = plt.gcf()
    plt.close()
    return fig_gcf
'''det_file_type_ocr function which will take file path as input and returns file type and string content.
There are 4 types of file
1)pdf_mob_file(pdf invoices):
    for pdf_mob_file we will read pdf file with "reader_pdf" function.Identify the type of bill whether petrol or mobile.
    Replace words like bill,receipt to invoice using regex.
2)pdf_petrol_file(petrol bill images saved as pdf type):
    if pdf_petrol_file we will convert pdf file to jpg file and run paddle ocr in that image.
3) if petrol image (img_petrol):
    first we will check whether orientation of image is vertical,if not
    we will rotate and make it  vertical,Then we will remove shadows from image.then normalize and resize the image and pass it to paddleOCR.
    after analysing ocr output using specific set of word lists.we may reverse image to get proper orientation and finally pass it to paddleOCR.
4)if screenshot images (img_mobile):
  First we will convert input image to high resolution image using ISR package then we will use ocrmypdf package to convert super resolution image to pdf.
  then we will read that pdf file as a string.
'''

def det_file_type_ocr(doc_path,password=None,ui=0):
    print(f"Input file is {doc_path} and password {password}")
    content_org = {}
    content_org["content_string"] = ""
    # for pdf files two types are orginal pdf invoices and images like petrol bill saved as pdf files.
    if Path(doc_path).suffix == ".pdf":
        content = reader_pdf(doc_path,password)
        print(f'pdf content {content["content_string"]}')
        str_words = content["content_string"].lower()
        if re.search(combined_mobile, str_words):
            print(f"re.search(combined_mobile,str_words) {re.search(combined_mobile,str_words)}")
            type_bill = 'pdf_mob_file'
        elif re.search(combined_petrol_bill,str_words):
            print(f"re.search(combined_petrol_bill, str_words) {re.search(combined_petrol_bill, str_words)}")
            type_bill = 'pdf_petrol_file'

        else:
            # for some particular type of pdf we are not able get proper characters after reading the file.For that type of file
            # we will set file type as image
            print("inside else pdf")
            if len(re.sub("[^a-zA-Z]", "", content["content_string"]))<50:
                type_bill = 'pdf_petrol_file'

            elif len(content["content_string"]) >= 45:
                type_bill = 'pdf_mob_file'
            else:
                type_bill = 'pdf_petrol_file'
        print(f"type_bill {type_bill}")
        if type_bill == 'pdf_petrol_file':

            images = convert_from_path(doc_path)
            #images[0].save('pdfimg_img.jpg')
            result = ocr.ocr(np.asarray(images[0]), cls=True)
            print("result {result}")
            list_bb = []
            list_word = []
            for pred in result:
                list_bb.append(((pred[0])))
                list_word.append(pred[1][0])
            content=sorted_text(list_bb,list_word)
    # two types of images are petrol images or screenshots
    else:
        str_words2=''
        img_orginal = (cv2.imread(doc_path))
        if ui==0:
            img_orginal = cv2.resize(img_orginal, None, fx=1.2, fy=1.2, interpolation=cv2.INTER_CUBIC)
        img_org=img_orginal
        mask = np.zeros(img_org.shape, dtype=np.uint8)
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
        h, w = mask.shape
        if h <w:
            print("rotating horizontal image to vertical")
            angle = 270
            rot_img = rotate(img_org, angle, resize=True)
            fig_rotate=gcf_array(rot_img)
            img_org = np.asarray(fig2image(fig_rotate))
        result_norm = shadow_removal(img_org)
        fig_sr = gcf_array(result_norm,dpi_value=1600/DPI,cmap='gray')
        img = result_norm
        n_img = normalize(img)
        n_img = resize_image_type0(n_img)
        fig_normalize=gcf_array(n_img[0],dpi_value=1600/DPI,cmap='bone')
        try:
            result_org = ocr.ocr(doc_path, cls=True)
            list_bb = []
            list_word = []
            for pred in result_org:
                list_bb.append(((pred[0])))
                list_word.append(pred[1][0])

            content_org = sorted_text(list_bb, list_word)
            print(f"list_word fig_normalize {len(list_word)}")
        except Exception as e:
            print(f"Error in converting orginal image to string {e}")
        result = ocr.ocr(np.asarray(fig2image(fig_normalize)), cls=True)
        list_bb = []
        list_word = []
        for pred in result:
            list_bb.append(((pred[0])))
            list_word.append(pred[1][0])
        if len(list_word)<30:
            list_word=[]
            list_bb=[]
            result=ocr.ocr(np.asarray(fig2image(fig_sr)), cls=True)
            for pred in result:
                list_bb.append(((pred[0])))
                list_word.append(pred[1][0])
            if len(list_word)<15:
                list_word=[]
                list_bb=[]
                result=ocr.ocr(doc_path)
                for pred in result:
                    list_bb.append(((pred[0])))
                    list_word.append(pred[1][0])
        str_words1 = " ".join(list_word).lower()
        top_list = [".*elcom|.*dealer"]
        bottom_list = [".*volum|.*hank|.*omplain|.*customer care|.*toll|.*free|.*wish|.*safe|.*driv|.*isit|.*gain|.*please"]
        img_rotate = False
        r = re.compile(f"(?i)({top_list[0]})")
        r_bottom = re.compile(f"(?i)({bottom_list[0]})")
        toplist = list(filter(r.match, list_word))
        bottomlist = list(filter(r_bottom.match, list_word))
        #try:
        if len(toplist) > 0:
            if list_word.index(toplist[0]) > len(list_word) / 2:
                img_rotate = True
                rot_img = rotate(n_img[0], 180, resize=True)
                fig_rotate = gcf_array(rot_img)
                plt.close()
        elif len(bottomlist) > 0:
            if list_word.index(bottomlist[0]) < len(list_word)* .5:
                img_rotate = True
                rot_img = rotate(n_img[0], 180, resize=True)
                fig_rotate = gcf_array(rot_img)
                plt.close()
        else:
            if len(list_word)<30:
                img_rotate = "both"
                rot_img = rotate(n_img[0], 180, resize=True)
                fig_rotate = gcf_array(rot_img)
                plt.close()
        if str(img_rotate)=="True" or str(img_rotate)=="both":
            result = ocr.ocr(np.asarray(fig2image(fig_rotate)), cls=True)
            list_bb_2 = []
            list_word_2 = []
            for pred in result:
                list_bb_2.append(((pred[0])))
                list_word_2.append(pred[1][0])
            str_words2=" ".join(list_word_2).lower()
        if str(img_rotate)=="True":
            str_words=str_words2
        elif  str(img_rotate)=="False":
            str_words = f"{str_words1}"
        elif str(img_rotate)=="both":
            str_words = f"{str_words1}\n{str_words2}"
        #if re.search(combined_petrol_bill, str_words):
        #   type_bill = "img_petrol"
        print(f"**********************************************************************************************\n {str_words}")
        if re.search(combined_mobile,str_words):
            print(f"re.search(combined_mobile,str_words) {re.search(combined_mobile,str_words)}")
            type_bill = "img_mob"
        elif re.search(combined_petrol_bill, str_words):
            print(f"re.search(combined_petrol_bill, str_words) {re.search(combined_petrol_bill, str_words)}")
            type_bill = "img_petrol"
        else:
            print(f"Detected type of file using length of words")
            type_bill = "img_petrol"
        if type_bill == 'img_mob':
            content=img_pdf_text(doc_path)
        elif type_bill == 'img_petrol':
            content={}
            if str(img_rotate)=="True":
                content2 = sorted_text(list_bb_2, list_word_2)
                content["content_string"]=f'{ content2["content_string"]}'
            elif str(img_rotate)=="False":
                content=sorted_text(list_bb,list_word)
            elif str(img_rotate) == "both":
                content = sorted_text(list_bb, list_word)
                content2 = sorted_text(list_bb_2, list_word_2)
                content["content_string"]=f' {content["content_string"]}\n{content2["content_string"]}'
    string_ocr =content_org["content_string"].lower()+ "\n"+content["content_string"]
    print(f"string_ocr before {string_ocr}")
    string_ocr=string_ocr.lower().replace("rate", "Market current price")
    string_ocr = string_ocr.lower().replace("ra1e", "Market current price")
    if type_bill=="pdf_mob_file" or type_bill=="img_mob":
        string_ocr=string_ocr.lower().replace('billing', 'invoice ').replace('receipt', 'invoice ').replace('bill','invoice ').replace('total invoice value ','invoice amount').replace('+',"").replace("taxable value ","")
        string_ocr=re.sub(r"invoice\s*(date|dete).","D number ",string_ocr.lower())
        string_ocr = re.sub(r'bittdate',"D number", string_ocr.lower())
        string_ocr = re.sub(r'charges\s*for\s*this\s*invoice\s*period',"invoice amount", string_ocr.lower())
        print(f"content_string final,{string_ocr}")
        return type_bill, string_ocr,password
    elif type_bill=='img_petrol' or type_bill=='pdf_petrol_file':
        df_ocr_words = pd.DataFrame()

        string_ocr = re.sub(r'：', ':', string_ocr.lower())
        string_ocr = re.sub('((amount)([ \(\)])*[:\.r])(.*)', r"invoice amount: \4", string_ocr.lower())
        string_ocr = re.sub(r'date', 'invoice date: ', string_ocr.lower())
        string_ocr = re.sub(r'bill sn|inv:|inv.num|tnv#|bi11no|rece:pt no|receipt no|bittno|bi77no:|invoiceno|inv#|billnumber|bsn', 'icode number = ', string_ocr.lower())
        string_ocr = re.sub(r'receipt|.*recei|.*bill', 'invoice ', string_ocr.lower())
        string_ocr = re.sub(r'.*ptno|otno', ' icode number = ', string_ocr.lower())
        string_ocr = re.sub(r'--', '-', string_ocr.lower())
        string_ocr = re.sub(r'(\s*=\s*\.\s*)', '=', string_ocr.lower())
        df_ocr_words["ocr_words"]=re.split(" {1}",string_ocr.lower().replace(':', ': ').replace('/', '/ ').replace('.', '. '))
        df_ocr_words[['simillarity', 'target_word']] = df_ocr_words.apply(lambda x: simillarity_check(x.ocr_words), axis=1, result_type='expand')
        df_ocr_words['replaced_words'] = df_ocr_words.apply(replace_words, axis=1)
        content_string = ' '.join(df_ocr_words['replaced_words'].to_list())
        if type_bill=="img_petrol":
            content_string=re.sub("(\s*:\s*\.\s*)",":",content_string.lower())
        print(f"content_string final,{content_string}")
        return type_bill, content_string, password


