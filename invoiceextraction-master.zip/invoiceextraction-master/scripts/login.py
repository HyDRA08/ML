from pydantic import BaseModel
import uvicorn
import secrets
import os
import shutil
import aiofiles
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi import FastAPI, File, UploadFile,Request
import datetime
app = FastAPI()

security = HTTPBasic()


class login_cred(BaseModel):
  user_name: str
  password: str




def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    correct_username = secrets.compare_digest(credentials.username, "spaceApp_user")
    correct_password = secrets.compare_digest(credentials.password, "spaceApp_pwd")
    if not (correct_username and correct_password):

        raise HTTPException(

            status_code=status.HTTP_401_UNAUTHORIZED,

            detail="Incorrect email or password",

            headers={"WWW-Authenticate": "Basic"},

        )

    return credentials.username


@app.get("/users/me")
def read_current_user(username: str = Depends(get_current_username)):

    return {"username": username}


@app.post("/users/me/post")
def post_current_user(username: str =Depends(get_current_username)):
    return {"username": username}




@app.post("/files/")
async def create_file(file: bytes = File(...)):
    return {"file_size": len(file)}


@app.post("/uploadfile/")

async def create_upload_file(file: UploadFile = File(...),username: str =Depends(get_current_username)):
    print(f"file upload {username}")
    destination_folder="./upload"
    out_file_path=os.path.join(destination_folder,f"{datetime.datetime.utcnow()}__{file.filename}")
    # ...
    async with aiofiles.open(out_file_path, 'wb') as out_file:
        while content := await file.read(1024):
            #content = await file.read()
            # async read chunk
            await out_file.write(content)  # async write chun


    return {"filename": file.filename}

if __name__ == "__main__":
    uvicorn.run('login:app', host='0.0.0.0', port=5052, reload=True, debug=True, workers=3)