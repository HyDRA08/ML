import pikepdf
from haystack.document_store.memory import InMemoryDocumentStore
from haystack.retriever.sparse import TfidfRetriever
from haystack.pipeline import ExtractiveQAPipeline
import re
#import datetime
from pathlib import Path
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import tempfile
import numpy as np
import pdftotext
import datefinder
from collections import Counter
from price_parser import Price
from word2number import w2n
from operator import is_not
from functools import partial

def info_detection(filename, context, query, reader):
    document_store = InMemoryDocumentStore()
    text = context
    docs = [{'text': text, 'meta': '1'}]
    document_store.write_documents(docs)
    try:
        retriever = TfidfRetriever(document_store=document_store)
        pipe = ExtractiveQAPipeline(reader, retriever)
        prediction = pipe.run(query=query, top_k_reader=5)
        df = pd.DataFrame(prediction['answers'])
        list_query = [prediction['query']] * len(df)
        list_filename = [filename] * len(df)
        df['query'] = list_query
        df['fileName'] = list_filename
    except Exception as e:
        print(f'Exception occured in info detection function,{e}')
        df = pd.DataFrame(
            columns=["answer", "score", "probability", "context", "offset_start", "offset_end", "document_id", "meta",
                     "query", "fileName"])
    return df

#function to read a pdf file with or without password
def reader_pdf(input_path,password=None,pwd_path="/home/athul/DataExtraction/output/pdf/"):
    print(f"Inside pdf_reader function.Input file is {input_path} and password is {password}")
    if password=='' or password==None:
        pdf_path=input_path
    # If password protected document we first save it as a normal pdf file,then extract content using pdftotext.
    else:
        pdf_pwd=pikepdf.open(input_path,password=password)
        pdf_path=f"{pwd_path}{datetime.datetime.now()}_{Path(input_path).stem}.pdf"
        pdf_pwd.save(pdf_path)
    #we will be reading first two pages from input pdf's
    with open(pdf_path, "rb") as f:
        pdf = pdftotext.PDF(f, )
        print(f"pdf {pdf}")
        pdf0 = pdf[0]
        print("pdf0", pdf0)
        try:
            pdf1=pdf[1]
        except Exception as e:
            pdf1=''

    content_string = pdf0+'\n'+pdf1
    return {"content_string":content_string}

def file_info_detection(question_list, doc_path, content_string, reader, threshold=0):
    print(f"Inside file_info_detection function")
    output_ans_list = []
    for question in question_list:
        ans = info_detection(doc_path, content_string, question, reader=reader)
        output_ans_list.append(ans)
    output_df = pd.concat(output_ans_list, axis=0, ignore_index=True)
    # filtering first output df
    output_df = output_df[output_df['answer'].notna()]
    output_df = output_df[(output_df['probability'] > threshold)]
    return output_df

def df_info_detection(input_df, reader):
    df_extracted_field1 = pd.DataFrame()
    # Running info detection function in filtered df
    df_extracted_field1['info_extraction'] = input_df.apply(
        lambda x: info_detection(x.fileName, x.context, x.query, reader), axis=1)
    df_list = [x for x in df_extracted_field1['info_extraction'].to_list() if str(x) != 'nan']
    output_df_double_filtered = pd.concat(df_list, axis=0)
    return output_df_double_filtered

def df_filter(df, filter_list, question_list):
    try:
        list_filtered_df = []
        for filter_value_index in range(0, len(filter_list)):
            if filter_value_index == 0:
                df_double_filtered = df[
                    (df['probability'] >= filter_list[filter_value_index]) & (df['probability'] <= 1)]
                df_double_filtered['filter_value'] = filter_list[filter_value_index]
            else:
                df_double_filtered = df[(df['probability'] >= filter_list[filter_value_index]) & (
                            df['probability'] <= filter_list[filter_value_index - 1])]
                df_double_filtered['filter_value'] = filter_list[filter_value_index]
            list_filtered_df.append(df_double_filtered)
        df_double_filtered_auto = pd.concat(list_filtered_df, axis=0)
        df_amount_2 = df_double_filtered_auto[df_double_filtered_auto['query'].isin(question_list)]
        df_amount_2['a_bsum'] = df_amount_2.groupby(['fileName', 'answer', 'filter_value'])['probability'].transform(
            sum)
        df_amount_2_sort = df_amount_2.sort_values(['filter_value', 'a_bsum', 'fileName', 'answer'],
                                                   ascending=[False, False, True, True])
        df_amount_2_sort = df_amount_2_sort.groupby('fileName').head(1)
        df_amount_2_sort = df_amount_2_sort.sort_values(['fileName'], ascending=[True])
    except Exception as e:
        df_amount_2_sort = pd.DataFrame(
            columns=["answer", "score", "probability", "context", "offset_start", "offset_end", "document_id", "meta",
                     "query", "fileName", "detected_answer", "filter_value", "a_bsum"])
    return df_amount_2_sort
def extract_date(date_detected):
    answer_date = []
    try:
        date_detected = date_detected.replace(" 1 ", "")
        date_detected = date_detected.replace('/ ', '/').replace("ti", " Ti")
        date_detected = re.sub(r'^(.+)([\d]{4})([\d]{2})', r'\1\2 \3', date_detected)
        match_regex = re.search(r'[\d]{3,4}:[\d]{0,2}', date_detected)
        regex_search_term = '(?i)(:ti)'
        regex_replacement = ': Ti'
        date_detected = re.sub(regex_search_term, regex_replacement, date_detected)
        #print(f"date_detected {date_detected}")
        list_dates = str(date_detected).split(':')
        date_list = []
        for date in list_dates:
            date=date.lower().replace("time","")
            date=re.sub('ime.*', '',date)
            #print(f"date {date}")
            try:
                if len(str(date)) > 6:
                    matches = datefinder.find_dates(f" {date} ")
                    for std_date in (matches):
                        #print(f"std_date {std_date}")
                        try:
                            letters = sum(c.isalpha() for c in date)
                            if match_regex:
                                year = f"20{str(std_date.year)[:2]}"
                            else:
                                year = std_date.year
                            if len(str(year))==3:
                                year = f"20{str(std_date.year)[:2]}"

                            if int(std_date.day) <= 12 and letters < 3:
                                date = str(year) + '-' + str('{:02d}'.format(std_date.day)) + '-' + str(
                                    '{:02d}'.format(std_date.month))
                            else:
                                date = str(year) + '-' + str('{:02d}'.format(std_date.month)) + '-' + str(
                                    '{:02d}'.format(std_date.day))
                            date_list.append(date)
                            #print("final date {date}")
                        except Exception as e:
                            print("Exception occured in find date {e}")
                            pass
            except Exception as e:
                #print(f"Exception occured in {date}, {e}")
                pass
        try:
            date_list = list(filter(partial(is_not, None), date_list))
            dict_date = (dict(Counter(date_list)))
            list_dates = (sorted(dict_date, key=dict_date.get, reverse=True))
            datetime_object = datetime.strptime(list_dates[0], '%Y-%m-%d')
            #print(f"datetime_object {datetime_object}")
            if datetime_object<=datetime.now()and datetime_object.year>2000:
                answer_date.append(list_dates[0])
            else:
                 answer_date.append('date not able to detect')
        except Exception as e:
            #print(e)
            answer_date.append('date not able to detect')
    except Exception as e:
        answer_date.append('date not able to detect')
    return str(answer_date[0])
def extract_invoice_number(invoice_number_detected):
    answer_invoice_number = []
    try:
        if invoice_number_detected.count("=") > 0:
                        invoice_number_detected = invoice_number_detected.split("=")[1]
    except:
        pass
    try:
        list_invoice=invoice_number_detected.split("\n")
        invoice_number_detected=list_invoice[0]
    except Exception as e:
        pass
    try:
        invoice_number_detected=invoice_number_detected.replace(".","")
    except Exception as e:
        pass
    try:
        if invoice_number_detected.count(" ") > 0:
            list_invoice = invoice_number_detected.split(" ")
            list_invoice = ([i for i in list_invoice if not i.isalpha()])
        elif invoice_number_detected.count(":") > 0:
            list_invoice = invoice_number_detected.split(":")
            list_invoice = [list_invoice[1]]
        else:
            list_invoice = [invoice_number_detected]
        list_invoice.sort(key=len, reverse=True)
        list_invoice = list(filter(partial(is_not, None), list_invoice))
        dict_invoice_number = dict(Counter(list_invoice))
        list_invoice_number = (sorted(dict_invoice_number, key=dict_invoice_number.get, reverse=True))
        try:
            string_invoice_number = re.sub(r'.：|.:|：|:', '', str(list_invoice_number[0]).lower())
            string_invoice_number = (string_invoice_number.replace('0rg', 'org'))
            if not string_invoice_number.isalpha() and len(str(string_invoice_number))>1:
                if string_invoice_number.count("=") > 0:
                    string_invoice_number = string_invoice_number.split("=")[1]
                string_invoice_number=re.sub(r'-org.*', '-orgnl', string_invoice_number.lower())
                answer_invoice_number.append(str(string_invoice_number.upper()))
            else:
                answer_invoice_number.append('invoice number not able to detect')
        except Exception as e:
            print(f"error in removing .: from invoice number {e}")
            if not string_invoice_number.isalpha() and len(str(string_invoice_number))>1:
                if string_invoice_number.count("=") > 0:
                    list_invoice_number = string_invoice_number.split("=")[1]
                answer_invoice_number.append(str(list_invoice_number[0]).upper())
            else:
                answer_invoice_number.append('invoice number not able to detect')
    except Exception as e:
        print(e)
        answer_invoice_number.append('invoice number not able to detect')
    return answer_invoice_number[0]

# Amount detecting new
list_amount_files = []
answer_amount = []
def extract_amount(amount_detected, petrol_img, only_words=False):
    try:
        amount_detected = amount_detected.replace("r8", "rs").replace("r5","rs")
    except Exception as e:
        pass
    answer_amount = []
    list_price = []
    list_word = []
    list_amount = [amount_detected]
    try:
        for x in list_amount:
            p = Price.fromstring(x)
            try:
                list_price.append((float(p.amount_float)))
            except Exception as e:
                amount_words_orginal = x
                amount_words_orginal = amount_words_orginal.replace('&', 'and')
                amount_words = amount_words_orginal.split(' and ')
                try:
                    if str(w2n.word_to_num(amount_words[0]))[-2:] == '00':
                        numerical_value = w2n.word_to_num(amount_words[0]) + w2n.word_to_num(amount_words[1])
                    else:
                        numerical_value = f"{w2n.word_to_num(amount_words[0])}.{w2n.word_to_num(amount_words[1])}"
                except Exception as e:
                    try:
                        numerical_value = f"{w2n.word_to_num(amount_words_orginal)}"
                    except Exception as e:
                        numerical_value=None
                        pass
                list_word.append(float(numerical_value))
    except Exception as e:
        print(f"Exception occur before parsing function {e}")
    list_word = list(filter(partial(is_not, None), list_word))
    list_price = list(filter(partial(is_not, None), list_price))
    if petrol_img:
        list_word = [x for x in list_word if x > 99 and x < 10000]
        list_price = [x for x in list_price if x > 99 and x < 10000]
    else:
        list_word = [x for x in list_word if x > 10]
        list_price = [x for x in list_price if x > 10]
    if only_words == True:
        list_final_amount = list_word
    else:
        list_final_amount = list_word + (list_price)
    list_final_amount = list(filter(partial(is_not, None), list_final_amount))
    try:
        dict_amount = dict(Counter(list_final_amount))
        list_final_amount = (sorted(dict_amount, key=dict_amount.get, reverse=True))
        if int(list_final_amount[0]) > 10000:
            answer_amount.append(round(list_final_amount[1],2))
        else:
            answer_amount.append((round(list_final_amount[0],2)))
    except Exception as e:
        answer_amount.append('amount not able to detect')
    return answer_amount[0]

#Inserting text in desired coordinates using  matplot lib
def sorted_text(list_bb, list_word):
    def custom_round(x, base=5):
        return int(base * round(float(x)/base))
    pdf_file = tempfile.NamedTemporaryFile(suffix='.pdf')
    list_cord_p1=[]
    list_cord_p2=[]
    list_cord_p3=[]
    list_cord_p4=[]
    for bbox in list_bb:
        list_cord_p1.append(bbox[0])
        list_cord_p2.append(bbox[1])
        list_cord_p3.append(bbox[2])
        list_cord_p4.append(bbox[3])
    list_text_plt = []
    for cord in list_cord_p1[::-1]:
        font=10
        n = '                                                                                                                '
        list_text_plt.append(f'plt.text({round(cord[0] / 100, 1)},{round(cord[1] / 100, 1)}, "{list_word[list_cord_p1.index(cord)]}  {n}", size={font}, color="black",horizontalalignment="left",verticalalignment="top")')
        list_text_plt.append(f"plt.text({round((cord[0] / 100) + 2, 1)},{round((cord[1] / 100) + 2, 1)}, '{n}', size=10)")
    fig, ax = plt.subplots()
    plt.axis([0, 5, 0, 5])
    plt.axis("off")
    for add_text in (list_text_plt):
        #print(add_text)
        eval(add_text)
    ax = plt.gca()  # get the axis
    ax.set_ylim(ax.get_ylim()[::-1])  # invert the axis
    ax.xaxis.tick_top()  # and move the X-Axis
    ax.yaxis.set_ticks(np.arange(0, 5, 1))  # set y-ticks
    ax.yaxis.tick_left()
    fig.savefig(f"{pdf_file.name}", bbox_inches='tight')
    # print(df_cord.head(25))
    content = reader_pdf(pdf_file.name)
    content_string=content["content_string"]
    #print(f"content_string {content_string}")
    return {"content_string": content_string}

