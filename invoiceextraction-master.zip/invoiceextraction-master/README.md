GPU Machine details:

	IP address: 122.15.225.249
	Internal IP address:10.9.2.43

General info:

	UI url:

		Network: http://10.9.2.43:3000/
		local: http://0.0.0.0:3000/

		Cerdentials:

			username:spaceApp_user
			password:spaceApp_pwd

	Swagger docs url:

		Network: http://10.9.2.43:5051/docs
		local: http://0.0.0.0:5051/docs

	redoc url:

		Network: http://10.9.2.43:5051/redoc
		local: http://0.0.0.0:5051/redoc

	ppt

	https://docs.google.com/presentation/d/1tAs96VkwuwOdmHctA0DQLVHRDsxfy4LnUn6sc10sobU/edit#slide=id.gdf3ef54d4a_0_43

Python script details:

	Backend:

		Virtual environment activation:	
			source /home/athul/DataExtraction/env_IE_testing/bin/activate
		Working directory:
			cd /home/athul/DataExtraction/docker_ie/docker
		Python server start cmd:
			uvicorn IE_app:app --host 0.0.0.0 --port 5052 --reload --debug --workers 3
	Frontend:
		Working directory:
			cd /home/athul/DataExtraction/docker_ie/frontend/invoice_extraction_fe/src
		node cmd:
			npm run start
Git Repo:

	Backend:
		https://code.qburst.com/alenaugusti/invoiceextraction.git
	Frontend:
		https://code.qburst.com/aravindrajan/invoice_extraction_fe.git
Docker details:

	Working directory:
	cd /home/athul/DataExtraction/docker_ie/docker

Docker commands:

	a)Backend
	1)Invoice Extraction backend docker without mount volume:
		sudo docker run -p 5051:5051 -ti --runtime=nvidia -e NVIDIA_DRIVER_CAPABILITIES=compute,utility -e NVIDIA_VISIBLE_DEVICES=all ie_app1:2
	2)Invoice Extraction backend docker with mount volume:
		sudo docker run -v /home/athul/DataExtraction/docker_ie/docker/output:/home/docker/output/ -v /home/athul/DataExtraction/docker_ie/docker/upload_ui/:/home/docker/upload_ui  -p 5051:5051 -ti --runtime=nvidia -e NVIDIA_DRIVER_CAPABILITIES=compute,utility -e NVIDIA_VISIBLE_DEVICES=all ie_app1:2
	3)Invoice Extraction backend docker tar file location:
		/home/athul/DataExtraction/docker_ie/docker_bkp/IE_extraction.tar.gz

	b)Frontend
	1)React frontend docker run command:
	  sudo docker run -p 3000:3000 ie_ui
	2)Invoice Extraction fronend docker tar file location:
	
LayoutLM package  for extracting details from invoices:

	Virtual environment activation:	
	 conda activate layoutLM_env
a) For preparing train and test dataset:

		cd /home/athul/DataExtraction/layoutLM/layoutLM_script
		python cmd to start server:
			uvicorn preprocess_lm1:app --host 0.0.0.0 --port 5053 --reload --debug --workers 3
		Sample request from Swagger UI for creating training dataset using paddleOCR that can be used for training model:
			{
		  "mode": "train",
		 
		  "ocr_input_dir": "/home/athul/DataExtraction/layoutLM/input_images/",
		  "ocr_output_dir": "/home/athul/DataExtraction/layoutLM/input_images/",
		   "entities_folder": "/home/athul/DataExtraction/layoutLM/label/",
		   "dataset_directory": "/home/athul/DataExtraction/layoutLM/output_preprocessing_LM/dataset_qburst_train1",
		  "det_model_dir": "/home/athul/DataExtraction/docker_ie/docker/ocr_models/ch_ppocr_server_v2.0_det_infer",
		  "rec_model_dir": "/home/athul/DataExtraction/docker_ie/docker/ocr_models/ch_ppocr_server_v2.0_rec_infer",
		  "cls_model_dir": "/home/athul/DataExtraction/docker_ie/docker/ocr_models/ch_ppocr_mobile_v2.0_cls_infer"
			}

		Sample request from Swagger UI for creating test dataset using paddleOCR that can be used fot testing model:

			{
			  "mode": "test",
			 
			  "ocr_input_dir": "/home/athul/DataExtraction/layoutLM/input_images/",
			  "ocr_output_dir": "/home/athul/DataExtraction/layoutLM/input_images/",
			   "entities_folder": "/home/athul/DataExtraction/layoutLM/label/"
			   "dataset_directory": "/home/athul/DataExtraction/layoutLM/output_preprocessing_LM/dataset_qburst_test"
			  "det_model_dir": "/home/athul/DataExtraction/docker_ie/docker/ocr_models/ch_ppocr_server_v2.0_det_infer",
			  "rec_model_dir": "/home/athul/DataExtraction/docker_ie/docker/ocr_models/ch_ppocr_server_v2.0_rec_infer",
			  "cls_model_dir": "/home/athul/DataExtraction/docker_ie/docker/ocr_models/ch_ppocr_mobile_v2.0_cls_infer"
			}



b) Cmd for training and testing the LayoutLM model on prepared train dataset:

	cd /home/athul/DataExtraction/layoutLM/output_preprocessing_LM/dataset_qburst/
	train:
		python run_seq_labeling.py                             --data_dir /home/athul/DataExtraction/layoutLM/output_preprocessing_LM/dataset_qburst/                             --labels /home/athul/DataExtraction/layoutLM/sroie_preprocessed//dataset/labels.txt                             --model_name_or_path output1/                             --model_type bert                             --do_lower_case                             --max_seq_length 512                            --do_train                             --logging_steps 10                             --save_steps -1                             --output_dir output1                             --per_gpu_eval_batch_size 8
	test:
		python run_seq_labeling.py                             --data_dir /home/athul/DataExtraction/layoutLM/output_preprocessing_LM/dataset_qburst_test/                             --labels /home/athul/DataExtraction/layoutLM/sroie_preprocessed//dataset/labels.txt                             --model_name_or_path output_qburst/                             --model_type bert                             --do_lower_case                             --max_seq_length 512                            --do_predict                             --logging_steps 10                             --save_steps -1                             --output_dir output_test_qburst                             --per_gpu_eval_batch_size 8

c)LayoutLM reference:

	https://github.com/microsoft/unilm/tree/master/layoutlm/deprecated
	
	
